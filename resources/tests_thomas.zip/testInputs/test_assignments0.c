int main() {
    int a = 0;
    int b = 7;
    float c = 9.0;
    char d = 't';
    char e = 'v';
    float v = 5.0;

    while (a <= 5) {
        int c = 5;
        c += 1;
        while (a <= 4) {
            int c = 5;
            c += 1;
            while (a <= 5) {
                int c = 5;
                c += 1;
            }
        }
    }

    return a;
}
