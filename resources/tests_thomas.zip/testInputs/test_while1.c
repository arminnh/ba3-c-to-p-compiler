void printf(char* string){
    return;
}
int main(){
        //declarations:
        int a = 1;
        int c;
        while (a == 5 && a != 6 && c <= 7 || a != 6 && 5 != 6 | 5 == 6) {
          printf("something something");
        }

        while (a == 5 && a != 6 && (c <= 7 || a != 6) && 5 != 6 | 5 == 6) {
          printf("something something");
        }

        return 0;
}
