void printf(char* string){
    return;
}
int main(){
        //declarations:
        int a = 1;
        int b = 2;

        if (a == 5) {
          printf("do stuff");
          while (a <= 5) {
            while (a >= 5) {
              while ( a== 5) {
                while (a != 5) {
                  if (a == 6) {
                    printf("hello anyone here?");
                    printf("seriously guys where did you go");
                    while (a <= 5) {
                      while (a >= 5) {
                        while ( a== 5) {
                          while (a != 5) {
                            if (a == 6) {
                              printf("nextLEvel!");
                            }
                            else {
                              printf("much nested looping very wow");
                              //TODO implement this?
                              // while (a = 1) {
                              //   printf("many doge");
                              // }
                            }
                          }
                        }
                      }
                    }
                  }
                  else {
                    printf("weuw");
                  }
                }
              }
            }
          }
        }
        else if (b == 7) {
            printf("do stuff");
        }
        else if (b != 4) {
          printf("do stuff");
          while (a <= 8) {
            while (a >= 8) {
              while ( a== 8) {
                while (a != 8) {
                  if (a == 9) {
                    printf("hello anyone here?2");
                    printf("seriously guys where did you go2");
                  }
                  else {
                    printf("weuw2");
                  }
                }
              }
            }
          }
        }
        else {
          printf("do stuff");
        }

        return 0;
}
