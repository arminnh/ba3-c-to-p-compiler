int main() {
    int a = 0;
    int b = 7;
    float c = 9.0;
    char d = 't';
    char e = 'v';
    float v = 5.0;

    return a;
}
