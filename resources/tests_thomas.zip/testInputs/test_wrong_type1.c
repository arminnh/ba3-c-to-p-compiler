int main() {
  int a = 5;
  float b = 0.7;
  char c = 'c';

  a = b;

  return 0;
}
