void printf(char* string){
    return;
}

//TODO doSTuff(int& a)
int doStuff(int a) {
  a += 5;
  return a;
}

int main(){
  printf("something happening inside the main function");
  return 0;
}
