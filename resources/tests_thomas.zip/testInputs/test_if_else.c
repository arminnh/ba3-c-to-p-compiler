void printf(char* string){
    return;
}

int main(){
        //declarations:
        int a;

        if (a == 1) {
          printf("something happens in the if part");
        }
        else {
          printf("something happens in the else part");
        }
        return 0;
}
