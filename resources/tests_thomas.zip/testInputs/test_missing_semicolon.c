#include <stdio.h>

int main(void) {
  int a
	return 0;
}
