int main() {
  return "a";
}
