void printf(char* string){
    return;
}

int main(){
        //declarations:
        int a;
        float b;
        if (a == 1) {
          printf("something happens in the if part");
        }
        else if ( b == 2.0) {
          printf("something going on in the elseif part");
        }
        else {
          printf("something happens in the else part");
        }

        return 0;
}
