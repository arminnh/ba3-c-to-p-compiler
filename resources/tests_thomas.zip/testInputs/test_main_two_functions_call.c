void printf(char* string){
    return;
}
//TODO doSTuff(int& a)
int doStuff(int a) {
  a += 5;
  return a;
}

float doMoreStuff(int b) {
  float c;
  b++;
  b--;
  ++b;
  --b;
  return c;
}

int main(){
  printf("something happening inside the main function");
  int a = 1;
  doStuff(a);
  doMoreStuff(a);
  return 0;
}
