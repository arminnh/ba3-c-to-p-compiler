void printf(char* string){
    return;
}

int main(){
  printf("something happening inside the main function");
  return 0;
}
