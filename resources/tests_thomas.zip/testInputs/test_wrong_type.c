int main() {
  int a = 5;
  int* b = &a;
  char* c;
  c = b;
}
