int main() {
	char* a = 'abcdef';
	float b = 0.5;
	int c = a = b;
	return 0;
}
