void printf(char* string){
    return;
}
int main(){
        //declarations:
        int a = 1;
        while (a == 5) {
          printf("something something");
        }

        return 0;
}
