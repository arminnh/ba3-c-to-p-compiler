void fct1(){
    int c = 0;
    int d = 5;
    char e = 'a';
    return;
}
void fct2(int a){
    int c = 0;
    int d = 5;
    void fct1(char c) {
      float d = 7.0;
    }
    char e = 'a';
    return;
}
void fct3(int a){
    int c = 0;
    int d = 5;
    char e = 'a';
    return;
}
void fct4(int b){
    int c = 0;
    int d = 5;
    char e = 'a';
    return;
}
void fct5(int a, int b){
    int c = 0;
    int d = 5;
    char e = 'a';
    return;
}

int main() {
    char a = 'a';
    float b = 7.0;
    int c = 9;
    char d = 't';
    char e = 'v';
    float v = 5.0;

    return c;
}
