void printf(char* string){
    return;
}
int main(){
        //declarations:
        int a = 1;
        int b = 2;
        while (a == 5 && a != 6) {
          printf("something something");
          if (a != 5) {
            printf("a is not equal to 5");
            if (b == 6) {
              printf("starting to nest now..");
              if (b == 4) {
                printf("starting to nest now..");
                if (b == 7) {
                  printf("starting to nest now..");
                  if (b == 8) {
                    printf("starting to nest now..");
                  }
                  else {
                    printf("ok no we're not");
                  }
                }
                else {
                  printf("ok no we're not");
                }
              }
              else {
                printf("ok no we're not");
              }
            }
            else {
              printf("ok no we're not");
            }
          }
          else if (a != 6) {
            printf("a is also not equal to 6");
          }
          else if (a != 7) {
            printf("or 7 yo wow");
          }
          else if (a == 8) {
            printf("woah its 8");
          }
          else {
            printf("thatll do");
          }
        }

        return 0;
}
