void printf(char* string){
    return;
}

int doStuff(int a) {
  a += 5;
  //declarations:
  int c = 1;
  int b = 2;

  if (a == 5) {
    printf("do stuff");
    while (a <= 5) {
      while (a >= 5) {
        a++;
        while ( a== 5) {
          while (a != 5) {
            if (a == 6) {
              --a;
              printf("hello anyone here?");
              printf("seriously guys where did you go");
              while (a <= 5) {
                while (a >= 5) {
                  while ( a== 5) {
                    a = b;
                    while (a != 5) {
                      if (a == 6) {
                        printf("nextLEvel!");
                      }
                      else {
                        printf("much nested looping very wow");
                        //TODO implement this?
                        // while (a = 1) {
                        //   printf("many doge");
                        // }
                      }
                    }
                  }
                }
              }
            }
            else {
              a++;
              printf("weuw");
            }
          }
        }
      }
    }
  }
  else if (b == 7) {
      printf("do stuff");
  }
  else if (b != 4) {
    printf("do stuff");
    while (a <= 8) {
      a += 1;
      a /= 1;
      a *= 1;
      a %= 1;
      while (a >= 8) {
        while ( a== 8) {
          while (a != 8) {
            if (a == 9) {
              printf("hello anyone here?2");
              printf("seriously guys where did you go2");
            }
            else {
              printf("weuw2");
            }
          }
        }
      }
    }
  }
  else {
    a = a + b++;
    a = --a++ + b++;
    printf("do stuff");
  }
  return a;
}

float doMoreStuff(int b) {
  float d;
  b++;
  b--;
  ++b;
  --b;
  return d;
}

int main(){
  printf("something happening inside the main function");
  int a = 1;
  doStuff(a);
  if(1) doMoreStuff(a);
  return 0;
}
