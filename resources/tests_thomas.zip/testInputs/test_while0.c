void printf(char* string){
    return;
}
int main(){
        //declarations:
        int a = 1;
        while (a == 5 && a != 6) {
          printf("something something");
        }

        return 0;
}
