void printf(char* string){
    return;
}
int main(){
        //declarations:
        int a;

        if (a == 1) {
          printf("something happens in the if part");
        }
        else if (a == 2) {
          printf("something going on in the elseif part");
        }
        else if ( a == 3) {
          printf("various things happening in the other elseif part");
        }
        return 0;
}
