void printf(char* string){
    return;
}
int main(){
        //declarations:
        int a;

        if (a == 1) {
          printf("something happens in the if part");
        }
        else if (a == 2) {
          printf("something going on in the elseif part");
        }
        else if ( a == 3) {
          printf("various things happening in the other elseif part");
        }
        else if (a == 4) {
          printf("something going on in the elseif part");
        }
        else if ( a == 5) {
          printf("testing continues");
        }
        else if (a == 6) {
          printf("and another one");
        }
        else if ( a == 7) {
          printf("sure why not");
        }
        else {
          printf("something happens in the else part");
        }

        return 0;
}
