int main(void) {
	&5;

	&"hi";

	&'b';

	&5.5;
}
