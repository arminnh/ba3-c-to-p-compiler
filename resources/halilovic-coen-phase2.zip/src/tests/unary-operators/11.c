int main(void) {
	--'a';
}
