int main(void) {
    float f = 4.3;
    float* ff = &f;
    !ff;
}
