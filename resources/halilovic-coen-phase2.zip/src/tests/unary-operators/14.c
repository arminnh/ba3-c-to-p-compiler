int main(void) {
	-2.5e-10;
}
