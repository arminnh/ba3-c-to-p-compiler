
int f(int* i) {
    return 0;
}

int main() {
    const int a = 5;
    f(&a);
}
