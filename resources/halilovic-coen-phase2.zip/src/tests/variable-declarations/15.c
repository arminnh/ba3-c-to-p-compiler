int main(void) {
    float a = {1.0};
}
