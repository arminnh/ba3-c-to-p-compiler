int main() {
    char y5[5];
    char (y6)[];
    char (y7[5]);
    char ((((((y8[5]))))));
    char (y9)[5];
    int (abla) = 5, blabla = 3, ((ablaba)[]) = {1, 2, 3};

    char *y[];
    char (*y2)[5];
    char *(y3[5]);
    char ((((*((y4[]))))));
    char *(*y10[]);

    return 0;
}
