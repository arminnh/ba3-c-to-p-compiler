int main(int argc, char *argv[]) {
	char str[] = "hello i am string";
	str[1];
}
