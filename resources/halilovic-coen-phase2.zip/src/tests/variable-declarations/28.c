int main() {
    int a, *b, * const * c;

    (const) a;

    (void *) b;

    (const * const *************const*****************************) c;

    return 0;
}
