int main() {
	int a = a;
	a;
}