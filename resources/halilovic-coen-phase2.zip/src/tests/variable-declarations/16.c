int main(void) {
    float a = {"error", 1, 2.0, '3', "aaa"};

    return a;
}
