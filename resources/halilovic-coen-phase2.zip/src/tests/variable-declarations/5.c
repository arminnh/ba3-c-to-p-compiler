int main() {
  int a = 8;
  int *b = a;
  char *c = a;
}
