int sub(const int a, int const * const b, const const const c);

int sub(const int a, int const * const b, const const const c) {
    return 0;
}

int main() {
    return 0;
}
