int main() {
	float f = (float) 1;
	const int* const i = (int*) 5;
	int* ii = (int*) i;
	int c = (int) 'a', d = (int) 'A';

	if ((int) i) {
		500;
	} else {
		400;
	}

	return 0;
}
