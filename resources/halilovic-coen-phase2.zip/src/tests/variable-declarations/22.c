int main() {
	char *str = "hello world";

	int a[str] = {1, 2, 3, 4, 5};
}
