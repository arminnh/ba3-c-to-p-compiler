#include <stdio.h>

int main() {
   int base, height;
   float area;

   printf("\nEnter the base of Right Angle Triangle : ");
   scanf("%d", &base);

   printf("\nEnter the height of Right Angle Triangle : ");
   scanf("%d", &height);

   area = 0.5 * (float) base * (float) height;
   printf("\nArea of Right Angle Triangle : %f", area);

   return (0);
}
