int main(void)
{
    ("3.0" ? "a" : "b");

    return 0;
}
