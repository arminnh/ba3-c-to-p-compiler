int main(void)
{
    float c[2] = {1.1, 2.2};
    (1 || 2 ? c[0] : 10);

    return 0;
}
