void sum3() {
    return;
}

int f2(int i) {
	return 1;
}

int main() {
	f2(sum3());

	void ablabla3;
	f2(ablabla3);
 }
