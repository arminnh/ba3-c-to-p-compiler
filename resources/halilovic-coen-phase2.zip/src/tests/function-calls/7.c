int f() {
    int a;
    return 0;
}

int main() {
    int a;
    f(0.0);
}
