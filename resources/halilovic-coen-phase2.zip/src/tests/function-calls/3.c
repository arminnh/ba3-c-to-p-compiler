int f(float a) {
  return 0;
}

int main() {
  f(0);
}
