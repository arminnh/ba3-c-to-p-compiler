void iojiofej(void *a) {
    return a;
}

int sum(int a, float b) {
    return 0;
}

float sub(void) {
    return 0.0;
}

int main(void) {
    return 0;
}

char* string(void) {
    return "hello";
}

char* string2(void) {
    return 'h';
}
