int sum(int a, int b);

int sum = 0;
