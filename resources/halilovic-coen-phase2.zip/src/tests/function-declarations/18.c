float* sum(int a, int b) {
	return 'a';
}

int main() {
	return 0.0;
}

