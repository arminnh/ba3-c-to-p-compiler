int sum(int a, int b);

int main(void) {
    sum(1, 2);

    return 1;
}
