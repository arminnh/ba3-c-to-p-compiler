int f(int a, int b) {
  return a - b % b;
}

int f(int a, int b) {
  return a - b % b;
}
