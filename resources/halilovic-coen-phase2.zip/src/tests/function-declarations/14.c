int foiejfoja(void, void *aaaa);

int foiejfoja(void a, void *aaaa) {
    return 0;
}
