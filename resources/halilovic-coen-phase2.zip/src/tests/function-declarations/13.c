int iojiofej(void a) {
    return a;
}
