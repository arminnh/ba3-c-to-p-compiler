nothing0() {
	return;
}

nothing1() {
	return;
}

* const * nothing2() {
	return;
}

nothing3() {
	return;
}

* nothing4() {
	return;
}

main() {
	return 0;
}
