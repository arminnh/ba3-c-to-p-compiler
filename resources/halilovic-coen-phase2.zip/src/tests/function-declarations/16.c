int iojiofej(void, void a) {
    return 0;
}

int sum(int a, float b) {
    return 0;
}

float sub(void) {
    return 0.0;
}
