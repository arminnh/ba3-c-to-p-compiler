int main(void) {
    54 * "a";

    return 1;
}
