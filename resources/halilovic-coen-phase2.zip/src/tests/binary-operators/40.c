int main() {
	int p[3];
	p + p;

	int* q;
	q - q;
}