int main(void) {
    "a" <= 'a';

    return 1;
}
