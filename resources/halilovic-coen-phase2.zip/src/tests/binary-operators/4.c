int main(void) {
    1.0 != 3;

    return 1;
}
