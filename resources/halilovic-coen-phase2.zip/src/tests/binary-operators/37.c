int sum (int a, int b) {
  return 0;
}

int main() {
    int a = sum(1, 2);

    int *b = &a;

    *b = 10;
    *(b+1) + 7 = 20;

    sum(1, 2) = 3;

    1 + 2 = a;
    "3" = a;
    5 && 9 = "hello";

    return 0;
}
