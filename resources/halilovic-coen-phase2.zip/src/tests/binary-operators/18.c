int main(void) {
    'c' * 5.9;

    return 1;
}
