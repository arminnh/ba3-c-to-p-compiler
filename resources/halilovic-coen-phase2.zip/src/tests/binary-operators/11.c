int main(void) {
    'a' < 1;

    return 1;
}
