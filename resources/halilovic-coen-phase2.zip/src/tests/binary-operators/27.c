int main(void) {
    0 || 0.4;

    return 0;
}
