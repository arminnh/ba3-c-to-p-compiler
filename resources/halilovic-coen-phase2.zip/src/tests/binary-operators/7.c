int main(void) {
    5 >= 6.0;

    return 1;
}
