int main(void) {
    5 + 5.0;

    return 1;
}
