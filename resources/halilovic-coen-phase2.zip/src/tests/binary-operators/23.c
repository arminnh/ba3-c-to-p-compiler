int main(void) {
    1.0 || 0;

    return 0;
}
