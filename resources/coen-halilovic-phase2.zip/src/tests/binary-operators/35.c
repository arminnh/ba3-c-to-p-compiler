int main() {
  int i = (5, 6), k;

  1, 2, 3;
  1, (2, 3);
  int ii, j;

  i = 5, j = 6;

  int kk = (i, j);

  return 0;
}
