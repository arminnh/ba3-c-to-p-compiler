int main(void) {
    int *a;
    float b[];

    a == b;

    return 1;
}
