int main(void) {
    5.0 - '5';

    return 1;
}
