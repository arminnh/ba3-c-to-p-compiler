int main(void) {
	int j;
	int i = (1, j = 	2), k = l;
	1, 2, 3;
}
