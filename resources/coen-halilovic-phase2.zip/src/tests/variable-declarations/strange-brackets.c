int main() {
    char y5[5];
    char (y6)[5];
    char (y7[5]);
    char ((((((y8[5]))))));
    char (y9)[5];
    int (abla) = 5, blabla = 3, ((ablaba)[3]) = {1, 2, 3};

    char *y[5];
    char (*y2)[5];
    char *(y3[5]);
    char ((((*((y4[5]))))));
    char *(*y10[4]);

    return 0;
}
