int sum(const a, const int * const b) {
    return 0;
}

int sub(const int a, int const * const b, const const const c);

int main() {
    const a;
    const int * const b;

    sum(4, b);
    sum(a, b);

    return 0;
}
