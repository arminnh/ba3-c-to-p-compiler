int main() {
	int a = a;
	int b = b + b;
	char c = c++;
}