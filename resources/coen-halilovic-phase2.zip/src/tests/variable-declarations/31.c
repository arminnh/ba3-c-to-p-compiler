int main(void) {
	char s1[] = "hello";
	char *s2 = "hello";

    char s3[] = {"hello", "world"};
    char *s4 = {"hello", "world"};

    char *s5[] = {"hello", "world"};

}
