int main() {
	int a[5.5] = {1, 2, 3, 4, 5};
}
