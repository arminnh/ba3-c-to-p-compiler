int main() {
  int arr[3] = {1, 2.0, 4};
}
