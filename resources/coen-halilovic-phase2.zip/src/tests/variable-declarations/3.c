int main() {
  int a;
  int b = 5.0;
}
