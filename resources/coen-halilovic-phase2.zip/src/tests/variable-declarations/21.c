int main() {
	int a["test"] = {1, 2, 3, 4, 5};
}
