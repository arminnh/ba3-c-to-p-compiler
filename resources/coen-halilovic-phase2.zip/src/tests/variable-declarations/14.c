int main(void) {
    float a = {"a"};
}
