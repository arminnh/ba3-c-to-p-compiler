int main() {
  int i;
  char c[] = "f";
  int a,b;
  a = b + (b + d) + c;
}
