int main() {
    const i;
    const const * const ii;
}
