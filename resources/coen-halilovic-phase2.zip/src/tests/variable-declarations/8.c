int main(void) {
    int j = "hello";
    
    int jj = {'h', 'e', 'l', 'l'};

    return 0;
}
