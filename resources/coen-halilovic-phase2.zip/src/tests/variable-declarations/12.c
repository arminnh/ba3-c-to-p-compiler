int main(int argc, char const * * const argv[]) {
	char *str[] = "hello i am string";
	char *str2[] = "hello i am string";
}
