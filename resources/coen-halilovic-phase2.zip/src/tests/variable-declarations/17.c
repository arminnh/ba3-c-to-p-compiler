int main(void) {
    int aa = {};

    return 0;
}
