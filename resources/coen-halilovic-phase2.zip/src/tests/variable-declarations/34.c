// scope test

int main() {
	{
		int a;
	}
	a;
}