int main(void) {
	++5;
}
