int main(void) {
    *5.0;
}
