int main(void) {
	char str[12] = "i am string";
	char c = str[9];
}
