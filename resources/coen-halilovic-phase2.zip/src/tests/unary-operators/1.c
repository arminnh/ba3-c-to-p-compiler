int main(void) {
    float f = 2.0;
    !f;
}
