nothing0();

* const * nothing2();

* nothing4();

main() {
	return 0;
}
