void nothing0() {
	return;
}

void* nothing1() {
	return;
}

void* const * nothing2() {
	return;
}

int nothing3() {
	return;
}

int* nothing4() {
	return;
}

int main() {
	return 0;
}
