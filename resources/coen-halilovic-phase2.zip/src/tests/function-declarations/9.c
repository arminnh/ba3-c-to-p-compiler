int sum (int a, int b) {
    return 1;
}

int sum(int a);
