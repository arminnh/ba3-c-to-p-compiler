int main()
{
    int i = 1, j=6, k, l = 0;
    k = ((i+j&&l)-j*2 % j) || i ? j < j % i + 1 : j-i*-1;
    
    return 0;
}

