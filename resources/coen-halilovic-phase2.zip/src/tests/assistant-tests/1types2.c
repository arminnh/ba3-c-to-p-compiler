int main()
{
    int i;
    int i2 = i;
    i = -1;

    return 0;
}

