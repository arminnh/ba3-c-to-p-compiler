#include <stdio.h>

int main() {
	char string[10];
	scanf("%s", &string);
}