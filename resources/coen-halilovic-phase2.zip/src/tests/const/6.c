int main() {
    int a = 10;
    const int* aa = &a;
    int* aaa = aa;
}
