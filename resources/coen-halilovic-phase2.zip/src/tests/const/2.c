int main() {
    int a = 5;
    const int b = a;

    // assign non-const value to const variable
    b = a;
}
