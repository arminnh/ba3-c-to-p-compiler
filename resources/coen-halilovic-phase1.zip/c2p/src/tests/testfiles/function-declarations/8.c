int sum (int, int) {
    return 1;
}
