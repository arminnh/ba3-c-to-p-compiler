int main(void) {
    return 0;
}

//int main(int argc, char *argv[]) {
int main(void) {
    return 1;
}
