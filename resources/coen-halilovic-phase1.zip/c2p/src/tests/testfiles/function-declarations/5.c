
int f(int a, int b);

int f(int a, float b) {

}
