int main() {
  int arr[3] = {1, 2, 4.0};
}
