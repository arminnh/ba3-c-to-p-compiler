int main(void) {
    int j = "hello"; // error

    return 0;
}
