int main(void) {
    4.6 / "a";

    return 1;
}
