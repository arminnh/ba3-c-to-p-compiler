int main(void) {
    10 % 5.0;

    return 1;
}
