int main(void) {
    10.5 > 10;

    return 1;
}
