int main(void) {
    float a;
    char *b = "char";

    a == b;

    return 1;
}
