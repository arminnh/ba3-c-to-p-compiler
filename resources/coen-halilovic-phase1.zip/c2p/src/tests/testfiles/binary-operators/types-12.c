int main(void) {
    1.0 < "a";

    return 1;
}
