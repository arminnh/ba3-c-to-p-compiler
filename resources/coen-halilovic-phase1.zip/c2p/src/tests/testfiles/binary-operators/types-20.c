int main(void) {
    1 / 1.0;

    return 1;
}
