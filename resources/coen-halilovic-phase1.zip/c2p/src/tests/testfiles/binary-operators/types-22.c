int main(void) {
    "a" % 4.0;

    return 1;
}
