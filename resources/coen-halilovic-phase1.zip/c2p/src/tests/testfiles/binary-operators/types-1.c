int main(void) {
    1 == 2.0;

    return 1;
}
