int main(void) {
    'a' && 0;

    return 0;
}
