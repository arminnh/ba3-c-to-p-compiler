int main(void) {
    "a" != 'b';

    return 1;
}
