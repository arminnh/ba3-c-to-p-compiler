int main(void)
{
    (1 || 2 ? 0 : 'a');

    return 0;
}
