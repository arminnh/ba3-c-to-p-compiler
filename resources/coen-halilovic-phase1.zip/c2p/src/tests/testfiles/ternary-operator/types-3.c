int main(void)
{
    (3 ? "a" : "b");

    return 0;
}
