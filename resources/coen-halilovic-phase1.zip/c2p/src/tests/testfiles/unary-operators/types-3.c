int main(void) {
    int i = 1;
    int* ii = &i;
    !ii;
}
