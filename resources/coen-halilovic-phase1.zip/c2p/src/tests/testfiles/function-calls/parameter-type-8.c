int f(int a) {
  return 0;
}

int main() {
  f();
}
