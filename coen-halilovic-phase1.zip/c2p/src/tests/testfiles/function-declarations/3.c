
int f(int a, int b) {
  return a - b % b;
}

float f(int a, int b) {
  return a - b % b;
}
