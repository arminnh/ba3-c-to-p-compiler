
int main(void) {
    sum(1, 2);
}
