int main(void) {
    1.6 && 0.6;

    return 0;
}
