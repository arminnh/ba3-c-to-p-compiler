int main(void) {
    4 > "a";

    return 1;
}
