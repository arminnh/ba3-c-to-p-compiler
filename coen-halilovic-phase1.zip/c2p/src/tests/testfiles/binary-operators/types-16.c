int main(void) {
    "a" - 'B';

    return 1;
}
