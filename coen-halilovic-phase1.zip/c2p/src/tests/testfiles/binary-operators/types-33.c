int main(void) {
    char a;
    char *b = "char";

    a == *b[0];

    return 1;
}
