int main(void) {
    char a;
    int b[5];

    a == b[0];

    return 1;
}
