int main(void) {
    int a = 1;
    float b = 1.0;

    a == b;

    return 1;
}
