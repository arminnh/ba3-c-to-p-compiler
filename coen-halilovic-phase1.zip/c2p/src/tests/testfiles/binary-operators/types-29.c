int main(void) {
    5 || "&";

    return 0;
}
