int f(int a, int b) {
  return 0;
}

int main() {
  f(0.0, 'a', 9);
}
