int main(void) {
    char c = 'g';
    !c;
}
