int main() {
  int b = 8;
  float a = 8;
}
