int main() {
  int a;
  float a;
}
